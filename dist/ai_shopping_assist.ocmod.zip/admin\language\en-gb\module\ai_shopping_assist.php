<?php
$_['heading_title'] = 'AI Shopping Assist';

$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified AI Shopping Assist!';
$_['text_edit'] = 'Edit AI Shopping Assist';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_logs'] = 'Recent chat logs';
$_['text_leads'] = 'Recent product enquiries';
$_['text_no_leads'] = 'No product enquiries yet.';
$_['text_no_logs'] = 'No chat logs yet.';
$_['text_clear_logs'] = 'Clear logs';
$_['text_export_excel'] = 'Export Excel';
$_['text_knowledge'] = 'Local knowledge base';
$_['text_knowledge_count'] = '%d records';
$_['text_knowledge_imported'] = 'Success: %d local knowledge records were imported.';
$_['text_knowledge_cleared'] = 'The local knowledge base was cleared.';
$_['text_catalog_index_progress'] = 'Indexed %d of %d catalog products.';
$_['text_catalog_index_complete'] = 'Success: all %d catalog products are now searchable.';
$_['text_clear_knowledge'] = 'Clear local knowledge';

$_['entry_status'] = 'Status';
$_['entry_gemini_api_key'] = 'Gemini API keys';
$_['entry_gemini_model'] = 'Gemini model';
$_['entry_gemini_temperature'] = 'Temperature';
$_['entry_catalog_limit'] = 'Prompt catalog limit';
$_['entry_store_brand'] = 'Store brand';
$_['entry_assistant_name'] = 'Assistant name';
$_['entry_sitemap_url'] = 'Sitemap URL';
$_['entry_system_prompt'] = 'System prompt';
$_['entry_catalog_token'] = 'Catalog token';
$_['entry_lead_webhook_url'] = 'Lead webhook URL';
$_['entry_lead_webhook_secret'] = 'Lead webhook secret';
$_['entry_footer_injection'] = 'Auto-inject widget';
$_['entry_widget_title'] = 'Widget title';
$_['entry_widget_button'] = 'Button text';
$_['entry_knowledge_file'] = 'Knowledge JSON file';

$_['help_gemini_api_key'] = 'Add one or more Google AI Studio keys separated by commas. OpenCart tries the next key if one fails or is rate-limited. Keys are used server-side and never exposed to the browser.';
$_['help_catalog_limit'] = 'Maximum live products sent to Gemini after retrieval. Use 8–12 for fast responses; the full catalog remains searchable in the local index.';
$_['help_sitemap_url'] = 'Optional. Paste your store sitemap URL so the assistant can use real internal links for navigation and suggestions.';
$_['help_system_prompt'] = 'Optional. Add store-specific rules, tone, link guidance, offer policy, or recommendation instructions. These rules are appended to every Gemini prompt.';
$_['help_catalog_token'] = 'Optional. If set, catalog JSON requests must include X-AI-Assistant-Token.';
$_['help_lead_webhook_url'] = 'Optional. Paste the Google Apps Script Web App URL. Product enquiry forms will be sent to this URL as JSON.';
$_['help_lead_webhook_secret'] = 'Optional shared secret. If set here, use the same value in Apps Script to reject unknown requests.';
$_['help_knowledge_file'] = 'Use Index all products for the full OpenCart catalog. Optionally import enriched_cache.json to add crawled pages and datasheet_content.';

$_['button_import_knowledge'] = 'Import JSON';
$_['button_rebuild_catalog'] = 'Index all products';

$_['column_date'] = 'Date';
$_['column_lead_id'] = 'Lead ID';
$_['column_product'] = 'Product';
$_['column_qty'] = 'QTY';
$_['column_name'] = 'Name';
$_['column_company'] = 'Company';
$_['column_contact'] = 'Contact';
$_['column_email'] = 'Email';
$_['column_delivery'] = 'Delivery location';
$_['column_log_id'] = 'Log ID';
$_['column_conversation'] = 'Conversation';
$_['column_session'] = 'Session';
$_['column_customer'] = 'Customer';
$_['column_role'] = 'Role';
$_['column_content'] = 'Content';
$_['column_ip'] = 'IP';
$_['column_user_agent'] = 'User agent';

$_['error_permission'] = 'Warning: You do not have permission to modify AI Shopping Assist!';
$_['error_gemini_api_key'] = 'At least one Gemini API key is required when the module is enabled.';
$_['error_knowledge_file'] = 'Choose a JSON knowledge file to import.';
$_['error_knowledge_size'] = 'The knowledge file must be 25 MB or smaller.';
$_['error_knowledge_json'] = 'The selected file is not valid JSON.';
$_['error_knowledge_empty'] = 'No usable product knowledge was found in the JSON file.';
$_['error_knowledge_import'] = 'The local knowledge operation failed. Check the OpenCart error log.';
$_['error_catalog_index'] = 'Catalog indexing failed. Check the OpenCart error log.';
